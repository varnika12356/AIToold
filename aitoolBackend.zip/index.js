const express = require("express");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
const cors = require("cors");
// const sendEmail = require('./utils/sendEmail');
// make connetion to MongoDB database
require("./src/db/db");

const app = express();
const router = express.Router();

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  next();
});

const http = require("http").Server(app);
// const server = http.createServer(app)

dotenv.config({ path: ".env" });
const PORT = process.env.PORT || 8080;

app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
app.use(express.json());
app.use(bodyParser.json());
app.use(cors());
app.use(express.static("public"));
app.get("/", (req, res) => {
  res.send(`<h1>Nothing to show</h1>`);
});
app.use("/", require("./src/routes/routes"));
app.use("/.netlify/functions/app", router);

http.listen(PORT, () => {
  console.log(`server is running on http://localhost:${PORT}`);
});
app.use(express.static(__dirname + "/public"));
