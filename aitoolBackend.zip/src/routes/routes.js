const express = require("express");
const router = express.Router();
const contactController = require("../controller/contactcontroller");
const userController = require("../controller/userController");
const toolController = require("../controller/toolController");
const emailcontroler = require("../controller/emailcontroller");
const reviewController = require("../controller/reviewcontroller");
const categoryController = require("../controller/categoryController");
const sendMessage = require("../controller/smsController");
const User = require("../schema/user");
const Category = require("../schema/category");
const Contact = require("../schema/contact");
const Tool = require("../schema/tool");
const Email = require("../schema/email");
const Review = require("../schema/reviews");
const {createFooter,getFooter} = require("../controller/footerController")

const { protect } = require("../Middleware/authMiddleware");


router.post("/createfooter",createFooter);
router.get("/getfooter",getFooter);

// ** User Controller All API ** //

//Login User Data API
router.post("/login", userController.login);

//Create User Data API
router.post("/signup", userController.signup);

//forgot data API
router.put("/forgot", userController.forgotdata);

//Get User Data by /:id API
router.get("/getprofiledata/:id", userController.getprof);

//Get All User Data API
router.get("/getuser", userController.getuser);

//Update User Data by /:id
router.put("/updateprofile/:id", userController.updateprof);

// ** Contact Controller All API ** //

// Create/Send Contact data API
router.post("/contact", contactController.submitContactForm);

//GET ALL Contact data API
router.get("/contacts", contactController.getAllContacts);

// ** Tool Controller All API ** //

//
router.post("/addTool", toolController.addTool);

// add Category

router.get("/getcategory", categoryController.getCategory);
router.post("/addcategory", categoryController.addCategory);

// Define route for '/AI'
router.get("/gettool", toolController.getTools);
// Define route for 'homeAi'
router.get("/homeAi", toolController.homeAI);

router.put("/updatetoolstatus/:id", toolController.updateToolStatus);
router.put("/ai/:id/updateFilter", toolController.updateFilter);
router.put("/tools/:toolId", toolController.updateToolData);
router.put("/updateVisitCount/:id", toolController.updateVisitCount);

router.delete("/deleteTool/:toolId", toolController.deleteTool);

//send message API
router.post("/sendsms", sendMessage);

// Route to create a new review for a specific tool
router.post("/tools/:toolId/reviews", reviewController.createReview);
router.get("/tools/:toolId/reviews", reviewController.getReviewsByToolId);
// POST route for creating a new email address
router.post("/emails", emailcontroler.replyOnQuery);

function getRandomMobileNumber() {
  // Mobile numbers usually start with a digit from 6 to 9 in many countries.
  const startDigit = getRandomInt(6, 9);

  // Generate the remaining 9 digits.
  let remainingDigits = "";
  for (let i = 0; i < 9; i++) {
    remainingDigits += getRandomInt(0, 9);
  }

  return `${startDigit}${remainingDigits}`;
}

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// router.get("/test", async (req, res) => {
//   try {
//     const fs = require("node:fs");
//     const path = require("node:path");

//     const filePath = path.join("ai-tools-database", "mockcontact.json");

//     if (!fs.existsSync(filePath)) {
//       return res.json({ msg: "File not found!" });
//     }

//     const fileData = JSON.parse(fs.readFileSync(filePath));

//     for (const data of fileData) {
//       let contact = await Contact.findOne({
//         name: data.name,
//         email: data.email,
//         message: data.message,
//       });

//       if (!contact) {
//         contact = await Contact.create({
//           name: data.name,
//           email: data.email,
//           message: data.message,
//         });
//       }

//       // const newData = {
//       //   title: data.toolTitle,
//       //   category: data.category,
//       //   description: data.toolDescription,
//       //   visit_link: data.visitLink || "na",
//       //   pricing: {
//       //     price: data.pricingPrice,
//       //     type: data.pricingType.toLowerCase() || "trial",
//       //   },
//       //   status: data.status,
//       //   visit_count: data.visitCount,
//       //   filter: data.filter,
//       //   firebase_image_url: data.firebaseImageUrl,
//       // };

//       // console.log("newData :>> ", newData);

//       // await Category.create(newData);
//     }

//     return res.json({ msg: "OK" });
//   } catch (err) {
//     return res.json({
//       err: err.message,
//       stack: err.stack,
//     });
//   }
// });

module.exports = router;
