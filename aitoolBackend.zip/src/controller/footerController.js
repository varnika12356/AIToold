const Footer = require("../schema/footerModel");

const createFooter = async (req, res) => {
  try {
    const {
      Image,
      websiteTitle,
      websiteAbout,
      subscribeAbout,
      gmailUrl,
      facebookUrl,
      twitterUrl,
      instagramUrl,
      linkedinUrl,
      copyRight,
    } = req.body;

    const newFooter = new Footer({
      image: Image,
      website_Title: websiteTitle,
      website_About: websiteAbout,
      subscribe_About: subscribeAbout,
      gmail_Url: gmailUrl,
      facebook_Url: facebookUrl,
      twitter_Url: twitterUrl,
      instagram_Url: instagramUrl,
      linkedin_Url: linkedinUrl,
      copy_Right: copyRight,
    });

    const footer = await newFooter.save();
    res.status(201).json(footer);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};

const getFooter = async (req, res) => {
  try {
    const footers = await Footer.find();
    res.status(200).json(footers);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

module.exports = {
  createFooter,
  getFooter,
};
