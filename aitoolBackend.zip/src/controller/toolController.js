// toolController.js
const Category = require("../schema/category");
const Review = require("../schema/reviews");
const Tool = require("../schema/tool");

// add tools
exports.addTool = async (req, res) => {
  try {
    const tool = await Tool.create({
      title: req.body.title,
      category: req.body.category,
      description: req.body.description,
      visit_link: req.body.visit_link,
      pricing: req.body.pricing,
      firebase_image_url: req.body.firebase_image_url,
    });

    res.status(201).json(tool);
  } catch (error) {
    console.error("Error adding tool:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

exports.homeAI = async (req, res) => {
  try {
    const results = await Tool.find({ filter: req.query.filter });
    res.json(results);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};

exports.getTools = async (req, res) => {
  try {
    const page = req.query.page || 1;
    const rows = req.query.rows || 12;
    const filter = new RegExp(req.query.filter?.trim(), 'i');
    
    const query = {};
    
    // console.log("filter",filter)

    if (filter) {
      const category = await Category.findOne({ name: filter });
      
      query["$or"] = [{ title: filter }, { filter: filter }];
      
      if (category) query["$or"].push({ category: filter });
    }
    
    // console.log("query :>> ", query);
    
    const total = await Tool.countDocuments(query);
    // console.log("total", total);

    const pages = Math.ceil(total / rows) || 1;

    if (page > pages) {
      res.status(400);
      throw new Error("Page limit exceeded!");
    }
    const startIdx = (page - 1) * rows;

    const results = { total, pages, page, result: [] };
    results.result = await Tool.find(query)
      .skip(startIdx)
      .limit(rows)
      .lean();

    for (const tool of results.result) {
      tool.status = tool.status == "true";
      const totalReviews = await Review.countDocuments({ productId: tool._id });
      tool.totalReviews = totalReviews;
    }
    // console.log("results",results)
    res.json(results);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};

exports.updateToolStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const updatedAI = await Tool.findByIdAndUpdate(
      id,
      { status },
      { new: true }
    );
    res.json(updatedAI);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
};
exports.updateVisitCount = async (req, res) => {
  try {
    const { id } = req.params;
    const updatedAI = await Tool.updateOne(
      { _id: id },
      {
        $inc: { visit_count: 1 },
      }
    );
    res.json(updatedAI);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
};

exports.updateFilter = async (req, res) => {
  try {
    const { id } = req.params;
    const { newFilter } = req.body;
    const updatedAI = await Tool.findByIdAndUpdate(
      id,
      { filter: newFilter },
      { new: true }
    );
    res.status(200).json({
      message: "Filter value updated successfully",
      updatedAI: updatedAI,
    });
  } catch (error) {
    console.error("Error updating filter value:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

exports.deleteTool = async (req, res) => {
  try {
    const { toolId } = req.params;
    const deletedTool = await Tool.findByIdAndDelete(toolId);
    if (!deletedTool) {
      return res
        .status(404)
        .json({ success: false, message: "Tool not found" });
    }
    res
      .status(200)
      .json({ success: true, message: "Tool deleted successfully" });
  } catch (error) {
    console.error("Error deleting tool:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

exports.updateToolData = async (req, res) => {
  try {
    const { toolId } = req.params;
    const updatedTool = await Tool.findByIdAndUpdate(toolId, req.body, {
      new: true,
    });
    if (!updatedTool) {
      return res
        .status(404)
        .json({ success: false, message: "Tool not found" });
    }
    res.status(200).json({ success: true, data: updatedTool });
  } catch (error) {
    console.error("Error updating tool data:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};
