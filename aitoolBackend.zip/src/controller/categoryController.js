const Category = require("../schema/category");

// add Category
exports.addCategory = async (req, res) => {
  try {
    const { name } = req.body;
    const newCategory = new Category({
      name,
    });
    await newCategory.save();
    res.status(201).json(newCategory);
  } catch (error) {
    console.error("Error adding tool:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

// get Category

exports.getCategory = async (req, res) => {
  try {
    const query = {};
    
    if (req.query.category) {
      query.category = req.query.category;
    }
    const CategoryData = await Category.find(query);
    if (!CategoryData) throw new Error({ message: "Category are not Get" });

    res.status(200).json(CategoryData);
  } catch (error) {
    console.log("Error Getting Tools", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};
