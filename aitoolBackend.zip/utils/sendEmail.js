require("dotenv").config();
const sgMail = require("@sendgrid/mail");
sgMail.setApiKey(
  "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"
);

const   sendEmail = async (to, from, subject, text) => {
  const msg = {
    to,
    from,
    subject,
    text,
  };
  await sgMail.send(msg, function (err, result) {
    if (err) {
      console.log("Email not Sent Error Occured");
    } else {
      console.log("Email was Sent");
    }
  });
};

module.exports = sendEmail;
